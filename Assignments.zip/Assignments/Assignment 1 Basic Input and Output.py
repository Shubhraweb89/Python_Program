name = input("Enter your name: ") #Inputing the name as a string
age = int(input("Enter your age: ")) #Inputing the age as an integer
age_5 = age+5 #Adding 5years with age
print("Hello ",name," you are ",age,"years old. After 5 years, you will be ",age_5," years old")