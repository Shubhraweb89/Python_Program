## SUM
a=int(input("Enter 1st number:"))
b=int(input("Enter 2nd number:")) #Taking input from user
sum= a+b
print("Sum:",sum)

## Difference
Difference=a-b
print("Difference",Difference)

##product
p=a*b
print("Product: ",p)

##Quotient
q=a/b
print("Quotient:",q)

##Remainder
r=a%b
print("Remainder:",r)
