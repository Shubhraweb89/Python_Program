a= int(input("Enter a number: "))
if(a%2==0): #compairing if the number is even or odd
    print("Even")
else:
    print("Odd")