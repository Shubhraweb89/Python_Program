word = input("Enter your word: ")  # Take input from the user
reversed_word = word[::-1]  # Reverse the string using slicing
print("Reversed word:", reversed_word)  # Print the reversed string
